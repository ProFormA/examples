package geom;
public class Circle {
    /** @return πr² */
	public static double calcArea(double r) { 
		return Math.PI * Square(r);
	}
	/** @return v² */
	private static double Square(double v) {
	    return v * v;
	}
	/* return √a / π */
	public static double calcRadius(double a) { 
		return Math.sqrt(a) / Math.PI; 
	}
}
